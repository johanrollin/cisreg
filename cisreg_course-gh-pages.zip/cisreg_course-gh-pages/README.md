# cisreg_course
Course on the analysis of cis-regulatory elements from genomic sequences

[[web site]](http://jvanheld.github.io/cisreg_course/)

